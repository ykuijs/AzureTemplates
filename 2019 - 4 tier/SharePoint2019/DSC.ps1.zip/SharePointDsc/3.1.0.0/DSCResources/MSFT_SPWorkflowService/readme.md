# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is used to register the SharePoint Server
against a Workflow Manager Instance.

Requirements:
Provide the url of the Workflow Manager instance to
connect to.
