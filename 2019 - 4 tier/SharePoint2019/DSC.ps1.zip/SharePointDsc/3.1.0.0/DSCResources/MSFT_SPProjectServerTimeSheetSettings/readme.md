# Description

**Type:** Distributed
**Requires CredSSP:** No

Allows you to configure the default timesheet settings for a specific PWA
instance.
